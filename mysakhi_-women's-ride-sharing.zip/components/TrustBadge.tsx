
import React from 'react';

interface TrustBadgeProps {
    icon: React.ReactNode;
    text: string;
}

const TrustBadge: React.FC<TrustBadgeProps> = ({ icon, text }) => {
    return (
        <div className="flex flex-col items-center text-center space-y-1">
            <div className="w-12 h-12 bg-sakhi-blue dark:bg-sakhi-blue-dark/50 rounded-full flex items-center justify-center text-sakhi-blue-dark dark:text-sakhi-blue-dark">
                {icon}
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-300 font-medium">{text}</p>
        </div>
    );
};

export default TrustBadge;
