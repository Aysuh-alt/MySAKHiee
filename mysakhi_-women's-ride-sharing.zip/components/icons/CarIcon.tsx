
import React from 'react';

const CarIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-5h-5l-4 5h5z"></path>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 16h5m-5 0l4-5H3l-4 5zM12 4v12m0-12a4 4 0 00-4 4h8a4 4 0 00-4-4z"></path>
    </svg>
);

export default CarIcon;
