
import React from 'react';

const SOSButton: React.FC = () => {
    return (
        <button 
            className="fixed bottom-20 right-4 z-50 w-16 h-16 bg-red-500 text-white rounded-full flex items-center justify-center shadow-2xl animate-pulse"
            aria-label="Emergency SOS"
        >
            <span className="text-xl font-bold">SOS</span>
        </button>
    );
};

export default SOSButton;
