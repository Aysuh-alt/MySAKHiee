
import React from 'react';
import type { Driver } from '../types';
import VerifiedIcon from './icons/VerifiedIcon';
import StarRating from './StarRating';

interface DriverCardProps {
    driver: Driver;
    onViewProfile: (driver: Driver) => void;
}

const DriverCard: React.FC<DriverCardProps> = ({ driver, onViewProfile }) => {
    return (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 transition-transform hover:scale-105">
            <div className="flex items-center space-x-4">
                <img src={driver.photoUrl} alt={driver.name} className="w-16 h-16 rounded-full border-2 border-pink-300" />
                <div className="flex-1">
                    <div className="flex items-center space-x-2">
                        <h3 className="text-lg font-bold text-gray-800 dark:text-white">{driver.name}</h3>
                        <VerifiedIcon className="w-5 h-5 text-blue-500" />
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-300">
                        <StarRating rating={driver.rating} />
                        <span className="font-semibold">{driver.rating}</span>
                        <span>({driver.rides} rides)</span>
                    </div>
                </div>
                <button 
                    onClick={() => onViewProfile(driver)}
                    className="text-pink-600 dark:text-pink-400 font-semibold text-sm hover:underline"
                >
                    View
                </button>
            </div>
        </div>
    );
};

export default DriverCard;
