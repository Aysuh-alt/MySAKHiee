import React, { useEffect, useState } from 'react';

const Confetti: React.FC = () => {
    // FIX: Changed JSX.Element to React.ReactElement to resolve "Cannot find namespace 'JSX'" error.
    const [pieces, setPieces] = useState<React.ReactElement[]>([]);

    useEffect(() => {
        const colors = ['bg-pink-400', 'bg-purple-400', 'bg-blue-400', 'bg-yellow-400'];
        const newPieces = Array.from({ length: 50 }).map((_, i) => {
            const style = {
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                transform: `rotate(${Math.random() * 360}deg)`,
                animationDuration: `${2 + Math.random() * 2}s`,
            };
            const color = colors[Math.floor(Math.random() * colors.length)];
            return <div key={i} className={`absolute top-0 w-2 h-4 ${color} animate-fall`} style={style}></div>;
        });
        setPieces(newPieces);
    }, []);

    return (
        <>
            <style>
                {`
                @keyframes fall {
                    0% { transform: translateY(-10vh) rotate(0deg); opacity: 1; }
                    100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
                }
                .animate-fall {
                    animation-name: fall;
                    animation-timing-function: linear;
                }
                `}
            </style>
            <div className="absolute inset-0 overflow-hidden pointer-events-none z-50">
                {pieces}
            </div>
        </>
    );
};

export default Confetti;