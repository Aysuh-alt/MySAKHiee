
import React from 'react';
import { MARKET_ITEMS } from '../constants';
import CoinIcon from '../components/icons/CoinIcon';

const MarketplaceScreen: React.FC = () => {
    return (
        <div className="p-4 bg-white dark:bg-black min-h-full">
            <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">Marketplace</h1>
            <p className="text-gray-500 dark:text-gray-400 mb-6">Support women-led businesses with your coins.</p>
            
            <div className="grid grid-cols-2 gap-4">
                {MARKET_ITEMS.map(item => (
                    <div key={item.id} className="bg-gray-50 dark:bg-gray-900 rounded-xl overflow-hidden shadow-md group">
                        <img src={item.imageUrl} alt={item.name} className="w-full h-32 object-cover transition-transform group-hover:scale-110 duration-300" />
                        <div className="p-3">
                            <h3 className="font-bold text-sm text-gray-800 dark:text-white truncate">{item.name}</h3>
                            <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">{item.seller}</p>
                            <button className="w-full bg-pink-100 dark:bg-pink-900/50 text-pink-700 dark:text-pink-300 text-sm font-bold py-1.5 rounded-lg flex items-center justify-center space-x-1 hover:bg-pink-200 dark:hover:bg-pink-900/80 transition-colors">
                                <CoinIcon className="w-4 h-4"/>
                                <span>{item.price}</span>
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default MarketplaceScreen;
