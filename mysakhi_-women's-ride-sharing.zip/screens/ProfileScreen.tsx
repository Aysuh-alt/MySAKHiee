
import React from 'react';
import VerifiedIcon from '../components/icons/VerifiedIcon';

interface ProfileScreenProps {
    isDarkMode: boolean;
    onToggleDarkMode: () => void;
}

const ProfileMenuItem: React.FC<{ icon: React.ReactNode; label: string; hasArrow?: boolean }> = ({ icon, label, hasArrow = true }) => (
    <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
        <div className="flex items-center space-x-4">
            <div className="text-pink-600 dark:text-pink-400">{icon}</div>
            <span className="font-medium text-gray-800 dark:text-gray-200">{label}</span>
        </div>
        {hasArrow && <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path></svg>}
    </div>
);

const ProfileScreen: React.FC<ProfileScreenProps> = ({ isDarkMode, onToggleDarkMode }) => {
    return (
        <div className="p-4 bg-white dark:bg-black min-h-full">
            <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-gray-100">Profile</h1>

            {/* User Info */}
            <div className="flex items-center space-x-4 mb-8">
                <img src="https://picsum.photos/seed/sunita/200/200" alt="Sunita Patil" className="w-20 h-20 rounded-full"/>
                <div>
                    <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Sunita Patil</h2>
                    <div className="flex items-center space-x-1 text-green-600 dark:text-green-400 text-sm font-semibold">
                        <VerifiedIcon className="w-4 h-4" />
                        <span>KYC Verified</span>
                    </div>
                </div>
            </div>

            {/* Menu */}
            <div className="space-y-3">
                <ProfileMenuItem icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" /></svg>} label="Payment Methods" />
                <ProfileMenuItem icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} label="Ride History" />
                <ProfileMenuItem icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>} label="Emergency Contacts" />
                <ProfileMenuItem icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>} label="Notifications" />
                
                <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <div className="flex items-center space-x-4">
                        <div className="text-pink-600 dark:text-pink-400">
                           <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
                        </div>
                        <span className="font-medium text-gray-800 dark:text-gray-200">Dark Mode</span>
                    </div>
                    <label htmlFor="dark-mode-toggle" className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" id="dark-mode-toggle" className="sr-only peer" checked={isDarkMode} onChange={onToggleDarkMode} />
                        <div className="w-11 h-6 bg-gray-200 dark:bg-gray-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-pink-600"></div>
                    </label>
                </div>
            </div>
        </div>
    );
};

export default ProfileScreen;
