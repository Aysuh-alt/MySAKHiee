
import React from 'react';
import type { Driver } from '../types';
import StarRating from '../components/StarRating';
import VerifiedIcon from '../components/icons/VerifiedIcon';
import ChevronLeftIcon from '../components/icons/ChevronLeftIcon';

interface DriverProfileScreenProps {
    driver: Driver;
    onBack: () => void;
}

const StatCard: React.FC<{ value: string | number; label: string }> = ({ value, label }) => (
    <div className="bg-sakhi-blue dark:bg-sakhi-blue-dark/30 p-3 rounded-lg text-center">
        <p className="text-xl font-bold text-sakhi-blue-dark dark:text-white">{value}</p>
        <p className="text-sm text-gray-600 dark:text-gray-300">{label}</p>
    </div>
);

const DriverProfileScreen: React.FC<DriverProfileScreenProps> = ({ driver, onBack }) => {
    return (
        <div className="bg-gray-50 dark:bg-gray-900 min-h-full">
            <div className="relative">
                <div className="h-28 bg-gradient-to-r from-pink-200 to-purple-200 dark:from-pink-800 dark:to-purple-800"></div>
                <button onClick={onBack} className="absolute top-4 left-4 bg-white/70 dark:bg-gray-800/70 rounded-full p-2 shadow-md backdrop-blur-sm">
                    <ChevronLeftIcon className="w-6 h-6 text-gray-800 dark:text-white"/>
                </button>
                <div className="absolute top-16 left-1/2 -translate-x-1/2">
                    <img src={driver.photoUrl} alt={driver.name} className="w-24 h-24 rounded-full border-4 border-white dark:border-gray-900 shadow-lg"/>
                </div>
            </div>

            <div className="pt-16 p-4 text-center">
                <div className="flex items-center justify-center space-x-2">
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{driver.name}</h1>
                    <VerifiedIcon className="w-6 h-6 text-blue-500" />
                </div>
                <p className="text-gray-600 dark:text-gray-300 mt-1">{driver.bio}</p>
            </div>

            <div className="p-4 grid grid-cols-3 gap-3">
                <StatCard value={driver.rating} label="Rating" />
                <StatCard value={driver.rides} label="Rides" />
                <StatCard value="2 yrs" label="Experience" />
            </div>

            <div className="p-4 space-y-4">
                <div>
                    <h3 className="font-semibold text-lg mb-2 text-gray-800 dark:text-gray-200">Safety Certifications</h3>
                    <div className="space-y-2">
                        {driver.safetyCertifications.map(cert => (
                            <div key={cert} className="flex items-center space-x-3 bg-white dark:bg-gray-800 p-3 rounded-lg">
                                <div className="bg-green-100 dark:bg-green-900 p-1.5 rounded-full"><VerifiedIcon className="w-5 h-5 text-green-600 dark:text-green-400" /></div>
                                <p className="font-medium text-gray-700 dark:text-gray-300">{cert}</p>
                            </div>
                        ))}
                    </div>
                </div>
                
                <div>
                    <h3 className="font-semibold text-lg mb-2 text-gray-800 dark:text-gray-200">Rider Reviews</h3>
                    <div className="space-y-3">
                        {driver.reviews.map((review, index) => (
                            <div key={index} className="bg-white dark:bg-gray-800 p-3 rounded-lg">
                                <div className="flex items-center space-x-2 mb-1">
                                    <img src={`https://picsum.photos/seed/${review.author}/40/40`} alt={review.author} className="w-6 h-6 rounded-full"/>
                                    <p className="font-semibold text-gray-800 dark:text-white">{review.author}</p>
                                </div>
                                <p className="text-gray-600 dark:text-gray-400 italic">"{review.comment}"</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default DriverProfileScreen;
