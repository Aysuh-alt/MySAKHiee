
import React, { useState } from 'react';
import type { Driver } from '../types';
import StarRating from '../components/StarRating';
import CoinIcon from '../components/icons/CoinIcon';
import Confetti from '../components/Confetti';

interface RideCompleteScreenProps {
    driver: Driver;
    onBookAgain: () => void;
    onDone: () => void;
}

const FeedbackTag: React.FC<{text: string; selected: boolean; onClick: () => void}> = ({text, selected, onClick}) => (
    <button onClick={onClick} className={`px-3 py-1.5 text-sm font-medium rounded-full border transition-colors ${selected ? 'bg-pink-600 text-white border-pink-600' : 'bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'}`}>
        {text}
    </button>
);

const RideCompleteScreen: React.FC<RideCompleteScreenProps> = ({ driver, onBookAgain, onDone }) => {
    const [rating, setRating] = useState(0);
    const [selectedTags, setSelectedTags] = useState<string[]>([]);
    
    const earnedCoins = 35;

    const toggleTag = (tag: string) => {
        setSelectedTags(prev => 
            prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
        );
    };

    return (
        <div className="relative min-h-full flex flex-col items-center justify-center p-4 text-center bg-white dark:bg-black overflow-hidden">
            <Confetti />
            
            <div className="animate-fade-in-up" style={{ animationDelay: '200ms' }}>
                <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">Ride Completed!</h1>
                <p className="text-gray-600 dark:text-gray-300 mb-6">Thank you for riding with MySakhi.</p>

                <div className="flex items-center justify-center space-x-2 bg-sakhi-gold dark:bg-sakhi-gold-dark/30 text-sakhi-gold-dark dark:text-sakhi-gold-dark font-bold py-2 px-4 rounded-full text-lg mb-8 animate-bounce" style={{ animationDelay: '400ms' }}>
                    <CoinIcon className="w-6 h-6"/>
                    <span>You earned {earnedCoins} coins!</span>
                </div>
            </div>

            <div className="w-full max-w-xs bg-gray-50 dark:bg-gray-900 p-6 rounded-2xl shadow-lg animate-fade-in-up" style={{ animationDelay: '600ms' }}>
                <img src={driver.photoUrl} alt={driver.name} className="w-24 h-24 rounded-full mx-auto -mt-16 border-4 border-white dark:border-black" />
                <h2 className="text-xl font-bold mt-4 text-gray-800 dark:text-white">Rate {driver.name}</h2>
                <div className="flex justify-center my-4">
                    <StarRating rating={rating} onRate={setRating} interactive={true} />
                </div>
                
                <div className="flex flex-wrap gap-2 justify-center mb-4">
                    <FeedbackTag text="Safe Driver" selected={selectedTags.includes('Safe Driver')} onClick={() => toggleTag('Safe Driver')} />
                    <FeedbackTag text="Clean Car" selected={selectedTags.includes('Clean Car')} onClick={() => toggleTag('Clean Car')} />
                    <FeedbackTag text="Friendly" selected={selectedTags.includes('Friendly')} onClick={() => toggleTag('Friendly')} />
                </div>
            </div>
            
            <div className="mt-8 w-full max-w-xs space-y-3 animate-fade-in-up" style={{ animationDelay: '800ms' }}>
                <button onClick={onBookAgain} className="w-full bg-pink-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-pink-700 transition-transform hover:scale-105">
                    Book Again
                </button>
                <button onClick={onDone} className="w-full text-gray-600 dark:text-gray-300 font-semibold py-3 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800">
                    Done
                </button>
            </div>
            <style>{`
                @keyframes fade-in-up {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in-up { animation: fade-in-up 0.5s ease-out forwards; }
            `}</style>
        </div>
    );
};

export default RideCompleteScreen;
