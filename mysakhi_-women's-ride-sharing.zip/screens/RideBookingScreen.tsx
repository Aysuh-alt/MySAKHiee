
import React from 'react';
import type { Driver } from '../types';
import MapPinIcon from '../components/icons/MapPinIcon';
import DriverCard from '../components/DriverCard';
import ChevronLeftIcon from '../components/icons/ChevronLeftIcon';

interface RideBookingScreenProps {
    driver: Driver;
    onConfirmBooking: () => void;
    onViewDriver: (driver: Driver) => void;
    onBack: () => void;
}

const RideBookingScreen: React.FC<RideBookingScreenProps> = ({ driver, onConfirmBooking, onViewDriver, onBack }) => {
    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900">
            {/* Map Placeholder */}
            <div className="flex-grow bg-gray-200 dark:bg-gray-700 relative">
                <img src="https://picsum.photos/400/600?grayscale" alt="Map for booking" className="w-full h-full object-cover opacity-50"/>
                <button onClick={onBack} className="absolute top-4 left-4 bg-white dark:bg-gray-800 rounded-full p-2 shadow-md">
                    <ChevronLeftIcon className="w-6 h-6 text-gray-800 dark:text-white"/>
                </button>
            </div>
            
            {/* Booking Details */}
            <div className="p-4 bg-white dark:bg-black rounded-t-3xl -mt-10 relative z-10 shadow-2xl">
                <div className="space-y-3 mb-4">
                    <div className="relative">
                        <MapPinIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-green-500" />
                        <input type="text" placeholder="Pickup location" defaultValue="Koramangala, Bengaluru" className="w-full bg-gray-100 dark:bg-gray-800 border-transparent rounded-lg py-3 pl-10 pr-4 focus:ring-pink-500 focus:border-pink-500" />
                    </div>
                    <div className="relative">
                        <MapPinIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-red-500" />
                        <input type="text" placeholder="Enter drop location" className="w-full bg-gray-100 dark:bg-gray-800 border-transparent rounded-lg py-3 pl-10 pr-4 focus:ring-pink-500 focus:border-pink-500" />
                    </div>
                </div>

                <div className="mb-4">
                    <h3 className="font-semibold text-gray-700 dark:text-gray-300 mb-2">Your Recommended Driver</h3>
                    <DriverCard driver={driver} onViewProfile={onViewDriver} />
                </div>
                
                <div className="flex justify-between items-center mb-4">
                    <span className="text-lg text-gray-600 dark:text-gray-300">Fare Estimate</span>
                    <span className="text-2xl font-bold text-gray-900 dark:text-white">₹185</span>
                </div>

                <button 
                    onClick={onConfirmBooking} 
                    className="w-full bg-pink-600 text-white font-bold py-4 rounded-xl shadow-lg hover:bg-pink-700 transition-transform hover:scale-105"
                >
                    Book Now
                </button>
            </div>
        </div>
    );
};

export default RideBookingScreen;
