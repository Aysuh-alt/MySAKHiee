
import React from 'react';
import CoinIcon from '../components/icons/CoinIcon';

const CoinWalletScreen: React.FC = () => {
    const balance = 2450;
    const progress = 70; // percentage to next reward

    const transactions = [
        { id: 1, type: 'Ride Earned', amount: 35, date: 'Today' },
        { id: 2, type: 'Redeemed: Coffee Voucher', amount: -200, date: 'Yesterday' },
        { id: 3, type: 'Ride Earned', amount: 50, date: '2 days ago' },
        { id: 4, type: 'Welcome Bonus', amount: 100, date: '1 week ago' },
    ];

    return (
        <div className="p-4 bg-white dark:bg-black text-gray-800 dark:text-gray-100 min-h-full">
            <h1 className="text-3xl font-bold mb-6">My Wallet</h1>

            {/* Balance Card */}
            <div className="bg-gradient-to-br from-pink-500 to-purple-600 text-white p-6 rounded-2xl shadow-xl mb-6">
                <p className="text-lg opacity-80">Total Balance</p>
                <div className="flex items-center space-x-2 mt-2">
                    <CoinIcon className="w-10 h-10 text-yellow-300" />
                    <span className="text-5xl font-bold">{balance.toLocaleString()}</span>
                </div>
            </div>

            {/* Next Reward */}
            <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-xl mb-6">
                <div className="flex justify-between items-center mb-2">
                    <p className="font-semibold">Next Reward: Free Ride</p>
                    <p className="font-bold text-pink-600 dark:text-pink-400">{progress}%</p>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div className="bg-pink-500 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                </div>
            </div>

            {/* Redemption Options could go here */}

            {/* Transaction History */}
            <div>
                <h2 className="text-xl font-bold mb-4">History</h2>
                <div className="space-y-3">
                    {transactions.map(tx => (
                        <div key={tx.id} className="flex justify-between items-center bg-gray-50 dark:bg-gray-900 p-3 rounded-lg">
                            <div>
                                <p className="font-semibold">{tx.type}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">{tx.date}</p>
                            </div>
                            <div className={`flex items-center font-bold ${tx.amount > 0 ? 'text-green-500' : 'text-red-500'}`}>
                                {tx.amount > 0 && <CoinIcon className="w-4 h-4 mr-1"/>}
                                <span>{tx.amount > 0 ? `+${tx.amount}` : tx.amount}</span>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default CoinWalletScreen;
