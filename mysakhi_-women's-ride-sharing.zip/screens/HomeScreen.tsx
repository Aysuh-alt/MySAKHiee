
import React from 'react';
import TrustBadge from '../components/TrustBadge';
import VerifiedIcon from '../components/icons/VerifiedIcon';
import CarIcon from '../components/icons/CarIcon';
import CoinIcon from '../components/icons/CoinIcon';

interface HomeScreenProps {
    onBookRide: () => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ onBookRide }) => {
    return (
        <div className="flex flex-col h-full text-gray-800 dark:text-gray-100">
            {/* Header */}
            <header className="p-4 flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold">MySakhi</h1>
                    <p className="text-gray-500 dark:text-gray-400">Welcome back, Sunita!</p>
                </div>
                <div className="flex items-center space-x-2 bg-sakhi-gold dark:bg-sakhi-gold-dark/30 text-sakhi-gold-dark dark:text-sakhi-gold-dark font-bold py-1 px-3 rounded-full">
                    <CoinIcon className="w-5 h-5" />
                    <span>2,450</span>
                </div>
            </header>

            {/* Map Placeholder */}
            <div className="flex-grow bg-gray-200 dark:bg-gray-700 relative flex items-center justify-center">
                 <img src="https://picsum.photos/400/600?grayscale" alt="Map of current location" className="w-full h-full object-cover opacity-50"/>
                 <div className="absolute inset-0 bg-gradient-to-t from-white dark:from-black via-white/50 dark:via-black/50 to-transparent"></div>
            </div>

            {/* Content Area */}
            <div className="p-4 bg-white dark:bg-black rounded-t-3xl -mt-10 relative z-10">
                <button 
                    onClick={onBookRide} 
                    className="w-full bg-pink-600 text-white font-bold py-4 rounded-xl shadow-lg hover:bg-pink-700 transition-all duration-300 transform hover:-translate-y-1"
                >
                    Book a Ride
                </button>
                <div className="mt-6">
                    <h2 className="text-lg font-semibold mb-3 text-center">Your Safety is Our Priority</h2>
                    <div className="grid grid-cols-3 gap-4">
                       <TrustBadge icon={<VerifiedIcon className="w-7 h-7" />} text="Verified Drivers" />
                       <TrustBadge icon={<CarIcon className="w-7 h-7" />} text="Live Tracking" />
                       <TrustBadge icon={<svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>} text="Secure Payments" />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default HomeScreen;
