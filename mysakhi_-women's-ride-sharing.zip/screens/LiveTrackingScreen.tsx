
import React from 'react';
import type { Driver } from '../types';
import ShareIcon from '../components/icons/ShareIcon';
import VerifiedIcon from '../components/icons/VerifiedIcon';
import CarIcon from '../components/icons/CarIcon';

interface LiveTrackingScreenProps {
    driver: Driver;
    onEndRide: () => void;
}

const LiveTrackingScreen: React.FC<LiveTrackingScreenProps> = ({ driver, onEndRide }) => {
    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900">
             <div className="flex-grow bg-gray-200 dark:bg-gray-700 relative flex items-center justify-center">
                <img src="https://picsum.photos/seed/livemap/400/800?grayscale" alt="Live tracking map" className="w-full h-full object-cover opacity-60"/>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                    <div className="animate-pulse">
                        <CarIcon className="w-12 h-12 text-pink-600"/>
                    </div>
                </div>
            </div>

            <div className="p-4 bg-white dark:bg-black rounded-t-3xl -mt-10 relative z-10 shadow-2xl">
                <div className="text-center mb-4">
                    <p className="text-gray-500 dark:text-gray-400">Arriving in</p>
                    <h2 className="text-4xl font-bold text-pink-600 dark:text-pink-400">8 MINS</h2>
                    <p className="text-gray-500 dark:text-gray-400">to HSR Layout, Bengaluru</p>
                </div>
                
                <hr className="my-4 border-gray-200 dark:border-gray-800" />
                
                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                        <img src={driver.photoUrl} alt={driver.name} className="w-16 h-16 rounded-full border-2 border-pink-300" />
                        <div>
                            <div className="flex items-center space-x-2">
                                <h3 className="text-lg font-bold text-gray-800 dark:text-white">{driver.name}</h3>
                                <VerifiedIcon className="w-5 h-5 text-blue-500" />
                            </div>
                            <p className="text-gray-600 dark:text-gray-300">{driver.vehicle}</p>
                            <p className="text-sm font-semibold bg-gray-200 dark:bg-gray-700 inline-block px-2 py-0.5 rounded">{driver.licensePlate}</p>
                        </div>
                    </div>
                    
                    <button className="flex flex-col items-center text-blue-500 space-y-1">
                        <ShareIcon className="w-7 h-7"/>
                        <span className="text-xs font-semibold">Share Trip</span>
                    </button>
                </div>
                 
                <button 
                    onClick={onEndRide} 
                    className="w-full mt-6 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white font-bold py-3 rounded-xl hover:bg-gray-300"
                >
                    (Dev) End Ride
                </button>
            </div>
        </div>
    );
};

export default LiveTrackingScreen;
