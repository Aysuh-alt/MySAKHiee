
import React, { useState, useEffect } from 'react';
import type { Screen, Driver } from './types';
import { DRIVERS } from './constants';
import HomeScreen from './screens/HomeScreen';
import RideBookingScreen from './screens/RideBookingScreen';
import LiveTrackingScreen from './screens/LiveTrackingScreen';
import RideCompleteScreen from './screens/RideCompleteScreen';
import DriverProfileScreen from './screens/DriverProfileScreen';
import CoinWalletScreen from './screens/CoinWalletScreen';
import MarketplaceScreen from './screens/MarketplaceScreen';
import ProfileScreen from './screens/ProfileScreen';
import BottomNavBar from './components/BottomNavBar';
import SOSButton from './components/SOSButton';

const App: React.FC = () => {
    const [currentScreen, setCurrentScreen] = useState<Screen>('Home');
    const [activeDriver, setActiveDriver] = useState<Driver | null>(DRIVERS[0]);
    const [isDarkMode, setIsDarkMode] = useState(false);
    
    useEffect(() => {
        if (isDarkMode) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    }, [isDarkMode]);

    const navigateTo = (screen: Screen) => {
        // A little delay to simulate screen transition
        setTimeout(() => setCurrentScreen(screen), 100);
    };

    const viewDriverProfile = (driver: Driver) => {
        setActiveDriver(driver);
        navigateTo('DriverProfile');
    };

    const renderScreen = () => {
        switch (currentScreen) {
            case 'Home':
                return <HomeScreen onBookRide={() => navigateTo('RideBooking')} />;
            case 'RideBooking':
                return <RideBookingScreen onConfirmBooking={() => navigateTo('LiveTracking')} onViewDriver={viewDriverProfile} driver={DRIVERS[0]} onBack={() => navigateTo('Home')} />;
            case 'LiveTracking':
                return <LiveTrackingScreen onEndRide={() => navigateTo('RideComplete')} driver={activeDriver || DRIVERS[0]} />;
            case 'RideComplete':
                return <RideCompleteScreen onBookAgain={() => navigateTo('RideBooking')} onDone={() => navigateTo('Home')} driver={activeDriver || DRIVERS[0]} />;
            case 'DriverProfile':
                return activeDriver ? <DriverProfileScreen driver={activeDriver} onBack={() => navigateTo('RideBooking')} /> : <HomeScreen onBookRide={() => navigateTo('RideBooking')} />;
            case 'Wallet':
                return <CoinWalletScreen />;
            case 'Marketplace':
                return <MarketplaceScreen />;
            case 'Profile':
                return <ProfileScreen isDarkMode={isDarkMode} onToggleDarkMode={() => setIsDarkMode(!isDarkMode)} />;
            default:
                return <HomeScreen onBookRide={() => navigateTo('RideBooking')} />;
        }
    };

    const showSOS = ['Home', 'RideBooking', 'LiveTracking'].includes(currentScreen);
    const showNav = ['Home', 'Wallet', 'Marketplace', 'Profile'].includes(currentScreen);

    return (
        <div className="bg-gray-50 dark:bg-gray-900 min-h-screen font-sans">
            <div className="relative mx-auto max-w-sm min-h-screen bg-white dark:bg-black shadow-2xl flex flex-col">
                <main className="flex-1 pb-20 overflow-y-auto">
                    {renderScreen()}
                </main>
                {showSOS && <SOSButton />}
                {showNav && <BottomNavBar activeScreen={currentScreen} onNavigate={navigateTo} />}
            </div>
        </div>
    );
};

export default App;
