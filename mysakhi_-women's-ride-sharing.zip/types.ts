
export type Screen = 'Home' | 'RideBooking' | 'LiveTracking' | 'RideComplete' | 'DriverProfile' | 'Wallet' | 'Marketplace' | 'Profile';

export interface Driver {
    id: number;
    name: string;
    photoUrl: string;
    rating: number;
    rides: number;
    bio: string;
    vehicle: string;
    licensePlate: string;
    safetyCertifications: string[];
    reviews: { author: string; comment: string; }[];
}

export interface MarketItem {
    id: number;
    name: string;
    seller: string;
    price: number;
    imageUrl: string;
}
