
import type { Driver, MarketItem } from './types';

export const DRIVERS: Driver[] = [
    {
        id: 1,
        name: 'Priya Sharma',
        photoUrl: 'https://picsum.photos/seed/priya/200/200',
        rating: 4.9,
        rides: 1250,
        vehicle: 'Maruti Suzuki Dzire',
        licensePlate: 'MH12 AB 3456',
        bio: 'Driving with MySakhi for 2 years. I love meeting new people and ensuring everyone has a safe and comfortable journey. Fluent in English, Hindi, and Marathi.',
        safetyCertifications: ['Defensive Driving Certified', 'First-Aid Trained'],
        reviews: [
            { author: 'Anjali', comment: 'Priya was so professional and friendly! Felt very safe.' },
            { author: 'Rina', comment: 'Clean car and a very smooth ride. Highly recommend.' }
        ]
    },
    {
        id: 2,
        name: 'Aisha Khan',
        photoUrl: 'https://picsum.photos/seed/aisha/200/200',
        rating: 4.8,
        rides: 890,
        vehicle: 'Hyundai Creta',
        licensePlate: 'DL3C CD 7890',
        bio: 'I am a mother of two and your safety is my top priority. I enjoy calm music during rides and believe in empowering women through my work.',
        safetyCertifications: ['Verified by MySakhi', 'CPR Certified'],
        reviews: [
            { author: 'Sneha', comment: 'Aisha is a wonderful person and a great driver.' },
            { author: 'Meera', comment: 'Felt like I was travelling with a friend.' }
        ]
    }
];

export const MARKET_ITEMS: MarketItem[] = [
    { id: 1, name: 'Handmade Scented Candles', seller: 'by Ritu\'s Creations', price: 250, imageUrl: 'https://picsum.photos/seed/candle/300/300' },
    { id: 2, name: 'Organic Skincare Set', seller: 'by GlowNatural', price: 800, imageUrl: 'https://picsum.photos/seed/skincare/300/300' },
    { id: 3, name: 'Custom Art Prints', seller: 'by ArtbyAnya', price: 500, imageUrl: 'https://picsum.photos/seed/art/300/300' },
    { id: 4, name: 'Gourmet Chocolate Box', seller: 'by ChocoDelight', price: 450, imageUrl: 'https://picsum.photos/seed/choco/300/300' },
    { id: 5, name: 'Beaded Jewellery', seller: 'by The Bead Story', price: 350, imageUrl: 'https://picsum.photos/seed/jewelry/300/300' },
    { id: 6, name: 'Embroidered Tote Bags', seller: 'by Threads & Co.', price: 600, imageUrl: 'https://picsum.photos/seed/bag/300/300' },
];
